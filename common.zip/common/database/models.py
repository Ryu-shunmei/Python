# coding: utf-8
from sqlalchemy import ARRAY, BigInteger, Boolean, Column, Date, DateTime, ForeignKey, Integer, Numeric, String, Text, UniqueConstraint, text
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import TIMESTAMP
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
metadata = Base.metadata


class CommonModel(Base):
    __abstract__ = True

    def toDict(self):
        """get dict from model.
        """
        return {clm.name: getattr(self, clm.name) for clm in self.__table__.columns}


class AccountType(CommonModel):
    __tablename__ = 'account_types'
    __table_args__ = {'comment': 'アカウント種別'}

    account_type_code = Column(
        String(2), primary_key=True, comment='アカウント種別コード')
    account_type_name = Column(String(255), comment='アカウント種別名称')


class AssistanceProjectFileCategoryCode(CommonModel):
    __tablename__ = 'assistance_project_file_category_codes'
    __table_args__ = {'comment': '補助事業ファイルカテゴリ'}

    assistance_project_file_category_code = Column(
        String(2), primary_key=True, comment='補助事業ファイルカテゴリコード')
    assistance_project_file_category_name = Column(
        String(255), comment='補助事業ファイルカテゴリ名称')


class AvgAgeType(CommonModel):
    __tablename__ = 'avg_age_types'
    __table_args__ = {'comment': '従業員の平均年齢区分'}

    avg_age_type_code = Column(
        String(1), primary_key=True, comment='従業員の平均年齢区分コード')
    avg_age_type_name = Column(String(255), comment='従業員の平均年齢区分名称')


class AvgServiceYearsType(CommonModel):
    __tablename__ = 'avg_service_years_types'
    __table_args__ = {'comment': '平均継続勤務年数区分'}

    avg_service_years_type_code = Column(
        String(1), primary_key=True, comment='平均継続勤務年数種別区分コード')
    avg_service_years_type_name = Column(String(255), comment='平均継続勤務年数種別区分名称')


class BasicInfo(CommonModel):
    __tablename__ = 'basic_infos'
    __table_args__ = {'comment': '法人基本情報'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('basic_infos_id_seq'::regclass)"), comment='ID')
    email_address = Column(String(255), comment='メールアドレス')
    corp_num = Column(String(13), comment='法人番号')
    corp_name = Column(String(80), comment='法人名称')
    corp_kana_name = Column(String(200), comment='法人カナ名称')
    corp_english_name = Column(String(255), comment='法人英記名称')
    head_office_add_pref_code = Column(String(2), comment='本社住所都道府県コード')
    head_office_add_city = Column(String(100), comment='本社住所町名（郡・市区町村～町名）')
    head_office_add_street = Column(String(100), comment='本社住所丁目以下')
    head_office_add_suburb = Column(String(100), comment='本社住所建物名等')
    head_office_post_code = Column(String(7), comment='本社郵便番号')
    head_office_biz_name = Column(String(80), comment='本社事業所名称')
    head_office_biz_add_pref_code = Column(String(2), comment='本社事業所住所都道府県コード')
    head_office_biz_add_city = Column(
        String(100), comment='本社事業所住所町名（郡・市区町村～町名）')
    head_office_biz_add_street = Column(String(100), comment='本社事業所住所丁目以下')
    head_office_biz_add_suburb = Column(String(100), comment='本社事業所住所建物名等')
    head_office_biz_post_code = Column(String(7), comment='本社事業所郵便番号')
    corp_est_date = Column(Date, comment='法人設立年月日')
    employees_num = Column(BigInteger, comment='従業員数')
    regular_employees_num = Column(BigInteger, comment='正社員数')
    corp_rep_last_name = Column(String(30), comment='法人代表者漢字氏名（姓）')
    corp_rep_kana_last_name = Column(String(30), comment='法人代表者カナ氏名（姓）')
    corp_rep_first_name = Column(String(30), comment='法人代表者漢字氏名（名）')
    corp_rep_kana_first_name = Column(String(30), comment='法人代表者カナ氏名（名）')
    corp_rep_title = Column(String(200), comment='法人代表者役職名称')
    corp_rep_birth = Column(Date, comment='法人代表者生年月日')
    delegator_rep_last_name = Column(String(30), comment='委任者漢字氏名（姓）')
    delegator_rep_kana_last_name = Column(String(30), comment='委任者カナ氏名（姓）')
    delegator_rep_first_name = Column(String(30), comment='委任者漢字氏名（名）')
    delegator_rep_kana_first_name = Column(String(30), comment='委任者カナ氏名（名）')
    delegate_start_date = Column(Date, comment='委任開始年月日')
    delegate_end_date = Column(Date, comment='委任終了年月日')
    delegator_role_desc = Column(String(10000), comment='委任者役割記述')
    delegator_affiliation_org_name = Column(String(80), comment='委任者所属組織名称')
    major_shareholder_name = Column(String(80), comment='大株主名称')
    corp_is_active = Column(Boolean, comment='法人活動有無判断フラグ')
    corp_activity_info_num = Column(BigInteger, comment='法人活動情報件数')
    corp_biz_type_type = Column(String(2), comment='法人事業形態区分')
    officers_total_num = Column(BigInteger, comment='役員全体人数')
    large_company_type = Column(Boolean, comment='大企業区分')
    settlement_date = Column(Date, comment='決算年月日')
    corp_homepage_url = Column(String(2000), comment='企業ホームページURL')
    total_asset_amt = Column(BigInteger, comment='総資産金額')
    corp_biz_summary = Column(String(10000), comment='事業概要')
    major_industry_code = Column(String(1), comment='業種大分類区分')
    medium_industry_code = Column(String(2), comment='業種中分類区分')
    small_industry_code = Column(String(3), comment='業種小分類区分')
    industry_type = Column(String(4), comment='業種区分')
    offices_num = Column(BigInteger, comment='事業所数')
    tax_income_is_conf = Column(Boolean, comment='課税所得基準適合判断フラグ')
    terms_is_consent = Column(Boolean, comment='利用規約同意フラグ')
    closure_reasons = Column(String(10000), comment='登記記録の閉鎖等の事由')
    closure_date = Column(Date, comment='登記記録の閉鎖等年月日')
    workplace_info = Column(String(10000), comment='職場情報')
    avg_service_years_type = Column(String(1), comment='平均継続勤務年数区分')
    avg_age_type = Column(String(1), comment='従業員の平均年齢区分')
    mo_avg_overtime_type = Column(String(1), comment='月平均所定外労働時間区分')
    female_workers_pct_type = Column(String(1), comment='労働者に占める女性労働者の割合区分')
    ministry_in_charge_code = Column(String(5), comment='担当府省コード')
    duration_service_years_type = Column(String(1), comment='平均継続勤務年数種別区分')
    male_company_size_details = Column(String(10000), comment='男性企業規模詳細')
    male_duration_service_years = Column(Numeric, comment='男性平均継続勤務年数')
    male_childcare_leave_num = Column(BigInteger, comment='男性育児休業対象者数')
    male_childcare_leave_taking_num = Column(BigInteger, comment='男性育児休業取得者数')
    female_company_size_details = Column(String(10000), comment='女性企業規模詳細')
    female_duration_service_years = Column(Numeric, comment='女性平均継続勤務年数')
    female_childcare_leave_num = Column(BigInteger, comment='女性育児休業取得者数')
    female_childcare_leave_taking_num = Column(
        BigInteger, comment='女性育児休業対象者数')
    female_managers_num = Column(BigInteger, comment='女性管理職人数')
    female_officers_num = Column(BigInteger, comment='女性役員人数')
    female_workers_pct = Column(Numeric, comment='労働者に占める女性労働者の割合')
    female_workers_pct_class_type = Column(
        String(1), comment='労働者に占める女性労働者の割合種別区分')
    females_managerial_pct = Column(Numeric, comment='管理職に占める女性の割合')
    last_updated_date = Column(DateTime, comment='最終更新日時')
    successor_is_exist = Column(Boolean, comment='後継者有無フラグ')
    delegate_app_num = Column(String(15), comment='委任申請番号')
    target_service_code = Column(String(5), comment='対象サービスコード')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')


class BizPartnerType(CommonModel):
    __tablename__ = 'biz_partner_types'
    __table_args__ = {'comment': '取引先区分'}

    biz_partner_type_code = Column(
        String(2), primary_key=True, comment='取引先区分コード')
    biz_partner_type_name = Column(String(255), comment='取引先区分名称')


class BizScaleType(CommonModel):
    __tablename__ = 'biz_scale_types'
    __table_args__ = {'comment': '事業規模区分'}

    biz_scale_type_code = Column(
        String(2), primary_key=True, comment='事業規模区分コード')
    biz_scale_type_name = Column(String(255), comment='事業規模区分名称')


class BizTypeType(CommonModel):
    __tablename__ = 'biz_type_types'
    __table_args__ = {'comment': '事業形態区分'}

    biz_type_type_code = Column(
        String(2), primary_key=True, comment='事業形態区分コード')
    biz_type_type_name = Column(String(255), comment='事業形態区分名称')


class BizinfoGepsShikakuTypesManufactureCode(CommonModel):
    __tablename__ = 'bizinfo_geps_shikaku_types_manufacture_codes'
    __table_args__ = {'comment': '政府統一参加資格（物品調達)-物品の製造'}

    bizinfo_geps_shikaku_types_manufacture_code = Column(
        String(1), primary_key=True, comment='政府統一参加資格（物品調達)-物品の製造コード')
    bizinfo_geps_shikaku_types_manufacture_name = Column(
        String(255), comment='政府統一参加資格（物品調達)-物品の製造名称')


class BizinfoGepsShikakuTypesPurchaseCode(CommonModel):
    __tablename__ = 'bizinfo_geps_shikaku_types_purchase_codes'
    __table_args__ = {'comment': '政府統一参加資格（物品調達）-物品の買受'}

    bizinfo_geps_shikaku_types_purchase_code = Column(
        String(1), primary_key=True, comment='政府統一参加資格（物品調達）-物品の買受コード')
    bizinfo_geps_shikaku_types_purchase_name = Column(
        String(255), comment='政府統一参加資格（物品調達）-物品の買受名称')


class BizinfoGepsShikakuTypesSalesCode(CommonModel):
    __tablename__ = 'bizinfo_geps_shikaku_types_sales_codes'
    __table_args__ = {'comment': '政府統一参加資格（物品調達）-物品の販売・役務の提供'}

    bizinfo_geps_shikaku_types_sales_code = Column(
        String(1), primary_key=True, comment='政府統一参加資格（物品調達）-物品の販売・役務の提供コード')
    bizinfo_geps_shikaku_types_sales_name = Column(
        String(255), comment='政府統一参加資格（物品調達）-物品の販売・役務の提供名称')


class CategoryAssoc(CommonModel):
    __tablename__ = 'category_assoc'
    __table_args__ = {'comment': 'カテゴリ紐付けマスタ:特定テーブルのカラムとカテゴリを紐付ける'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('category_assoc_id_seq'::regclass)"), comment='ID')
    category_code = Column(String(2), nullable=False, comment='カテゴリコード')
    table_name = Column(Text, comment='テーブル名')
    culumn_name = Column(Text, comment='カラム名')


class Category(CommonModel):
    __tablename__ = 'categorys'
    __table_args__ = {'comment': 'カテゴリコードマスタ:カテゴリコードマスタ'}

    category_code = Column(String(2), primary_key=True, comment='カテゴリコード')
    category_code_name = Column(Text, comment='カテゴリコード名称')
    is_control = Column(Boolean, comment='公開非公開コントロール不可フラグ')


class CorpBizTypeType(CommonModel):
    __tablename__ = 'corp_biz_type_types'
    __table_args__ = {'comment': '法人事業形態区分'}

    corp_biz_type_type_code = Column(
        String(2), primary_key=True, comment='法人事業形態区分コード')
    corp_biz_type_type_name = Column(String(255), comment='法人事業形態区分名称')


class CorpType(CommonModel):
    __tablename__ = 'corp_types'
    __table_args__ = {'comment': '事業形態'}

    corp_type_code = Column(String(2), primary_key=True, comment='事業形態コード')
    corp_type_name = Column(String(255), comment='事業形態名称')


class FemaleWorkersPctType(CommonModel):
    __tablename__ = 'female_workers_pct_types'
    __table_args__ = {'comment': '労働者に占める女性労働者の割合区分'}

    female_workers_pct_type_code = Column(
        String(1), primary_key=True, comment='労働者に占める女性労働者の割合区分コード')
    female_workers_pct_type_name = Column(
        String(255), comment='労働者に占める女性労働者の割合区分名称')


class GbizinfoAreaCode(CommonModel):
    __tablename__ = 'gbizinfo_area_codes'
    __table_args__ = {'comment': '営業エリアコード:gbizinfoが定義する地域のコード'}

    biz_area_code = Column(String(2), primary_key=True, comment='営業エリアコード')
    biz_area_name = Column(String(255), comment='営業エリア名称')


class GbizinfoBizItemCode(CommonModel):
    __tablename__ = 'gbizinfo_biz_item_codes'
    __table_args__ = {'comment': '営業項目コード:gbizinfoが定義する営業項目のコード'}

    biz_item_code = Column(String(3), primary_key=True, comment='営業項目コード')
    biz_item_name = Column(String(255), comment='営業項目名称')


class GenderCode(CommonModel):
    __tablename__ = 'gender_codes'
    __table_args__ = {'comment': '性別コード'}

    gender_code = Column(String(1), primary_key=True, comment='性別コード')
    gender_name = Column(String(255), comment='性別名称')


class Group(CommonModel):
    __tablename__ = 'groups'
    __table_args__ = {'comment': 'グループコードマスタ:グループコードマスタ'}

    support_agency_group_code = Column(
        String(2), primary_key=True, comment='支援機関グループコード')
    support_agency_group_name = Column(Text, comment='支援機関グループ名称')


class IndustryType(CommonModel):
    __tablename__ = 'industry_types'
    __table_args__ = {'comment': '業種区分'}

    industry_type_code = Column(String(4), primary_key=True, comment='業種区分コード')
    industry_type_name = Column(String(255), comment='業務区分名称')


class IntellectualPropTypeCode(CommonModel):
    __tablename__ = 'intellectual_prop_type_codes'
    __table_args__ = {'comment': '知的財産権区分コード'}

    intellectual_prop_type_code = Column(
        String(5), primary_key=True, comment='知的財産権区分コード')
    intellectual_prop_type_name = Column(String(255), comment='知的財産権区分名称')


class IntellectualPropType(CommonModel):
    __tablename__ = 'intellectual_prop_types'
    __table_args__ = {'comment': '知的財産権区分'}

    intellectual_prop_type_code = Column(
        String(2), primary_key=True, comment='出願分類コード')
    intellectual_prop_type_name = Column(String(255), comment='出願分類名称')


class MajorIndustryCode(CommonModel):
    __tablename__ = 'major_industry_codes'
    __table_args__ = {'comment': '業種大分類'}

    major_industry_code = Column(
        String(1), primary_key=True, comment='業種大分類コード')
    major_industry_name = Column(String(255), comment='業種大分類名称')


class MediumIndustryCode(CommonModel):
    __tablename__ = 'medium_industry_codes'
    __table_args__ = {'comment': '業種中分類'}

    medium_industry_code = Column(
        String(2), primary_key=True, comment='業種中分類コード')
    medium_industry_name = Column(String(255), comment='業種中分類名称')


class MinistryCode(CommonModel):
    __tablename__ = 'ministry_codes'
    __table_args__ = {'comment': '府省コード'}

    ministry_code = Column(String(5), primary_key=True, comment='府省コード')
    ministry_name = Column(String(255), comment='府省名称')


class MoAvgOvertimeType(CommonModel):
    __tablename__ = 'mo_avg_overtime_types'
    __table_args__ = {'comment': '月平均所定外労働時間区分'}

    mo_avg_overtime_type_code = Column(
        String(1), primary_key=True, comment='月平均所定外労働時間区分コード')
    mo_avg_overtime_type_name = Column(String(255), comment='月平均所定外労働時間区分名称')


class MstBasicInfo(CommonModel):
    __tablename__ = 'mst_basic_infos'
    __table_args__ = {'comment': '[マスタ]法人基本情報'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_basic_infos_id_seq'::regclass)"), comment='ID')
    email_address = Column(String(255), comment='メールアドレス')
    corp_num = Column(String(13), unique=True, comment='法人番号')
    corp_name = Column(String(80), comment='法人名称')
    corp_kana_name = Column(String(200), comment='法人カナ名称')
    corp_english_name = Column(String(255), comment='法人英記名称')
    head_office_add_pref_code = Column(String(2), comment='本社住所都道府県コード')
    head_office_add_city = Column(String(100), comment='本社住所町名（郡・市区町村～町名）')
    head_office_add_street = Column(String(100), comment='本社住所丁目以下')
    head_office_add_suburb = Column(String(100), comment='本社住所建物名等')
    head_office_post_code = Column(String(7), comment='本社郵便番号')
    head_office_biz_name = Column(String(80), comment='本社事業所名称')
    head_office_biz_add_pref_code = Column(String(2), comment='本社事業所住所都道府県コード')
    head_office_biz_add_city = Column(
        String(100), comment='本社事業所住所町名（郡・市区町村～町名）')
    head_office_biz_add_street = Column(String(100), comment='本社事業所住所丁目以下')
    head_office_biz_add_suburb = Column(String(100), comment='本社事業所住所建物名等')
    head_office_biz_post_code = Column(String(7), comment='本社事業所郵便番号')
    corp_est_date = Column(Date, comment='法人設立年月日')
    employees_num = Column(BigInteger, comment='従業員数')
    regular_employees_num = Column(BigInteger, comment='正社員数')
    corp_rep_last_name = Column(String(30), comment='法人代表者漢字氏名（姓）')
    corp_rep_kana_last_name = Column(String(30), comment='法人代表者カナ氏名（姓）')
    corp_rep_first_name = Column(String(30), comment='法人代表者漢字氏名（名）')
    corp_rep_kana_first_name = Column(String(30), comment='法人代表者カナ氏名（名）')
    corp_rep_title = Column(String(200), comment='法人代表者役職名称')
    corp_rep_birth = Column(Date, comment='法人代表者生年月日')
    delegator_rep_last_name = Column(String(30), comment='委任者漢字氏名（姓）')
    delegator_rep_kana_last_name = Column(String(30), comment='委任者カナ氏名（姓）')
    delegator_rep_first_name = Column(String(30), comment='委任者漢字氏名（名）')
    delegator_rep_kana_first_name = Column(String(30), comment='委任者カナ氏名（名）')
    delegate_start_date = Column(Date, comment='委任開始年月日')
    delegate_end_date = Column(Date, comment='委任終了年月日')
    delegator_role_desc = Column(String(10000), comment='委任者役割記述')
    delegator_affiliation_org_name = Column(String(80), comment='委任者所属組織名称')
    major_shareholder_name = Column(String(80), comment='大株主名称')
    corp_is_active = Column(Boolean, comment='法人活動有無判断フラグ')
    corp_activity_info_num = Column(BigInteger, comment='法人活動情報件数')
    corp_biz_type_type = Column(String(2), comment='法人事業形態区分')
    officers_total_num = Column(BigInteger, comment='役員全体人数')
    large_company_type = Column(Boolean, comment='大企業区分')
    settlement_date = Column(Date, comment='決算年月日')
    corp_homepage_url = Column(String(2000), comment='企業ホームページURL')
    total_asset_amt = Column(BigInteger, comment='総資産金額')
    corp_biz_summary = Column(String(10000), comment='事業概要')
    major_industry_code = Column(String(1), comment='業種大分類区分')
    medium_industry_code = Column(String(2), comment='業種中分類区分')
    small_industry_code = Column(String(3), comment='業種小分類区分')
    industry_type = Column(String(4), comment='業種区分')
    offices_num = Column(BigInteger, comment='事業所数')
    tax_income_is_conf = Column(Boolean, comment='課税所得基準適合判断フラグ')
    terms_is_consent = Column(Boolean, comment='利用規約同意フラグ')
    closure_reasons = Column(String(10000), comment='登記記録の閉鎖等の事由')
    closure_date = Column(Date, comment='登記記録の閉鎖等年月日')
    workplace_info = Column(String(10000), comment='職場情報')
    avg_service_years_type = Column(String(1), comment='平均継続勤務年数区分')
    avg_age_type = Column(String(1), comment='従業員の平均年齢区分')
    mo_avg_overtime_type = Column(String(1), comment='月平均所定外労働時間区分')
    female_workers_pct_type = Column(String(1), comment='労働者に占める女性労働者の割合区分')
    ministry_in_charge_code = Column(String(5), comment='担当府省コード')
    duration_service_years_type = Column(String(1), comment='平均継続勤務年数種別区分')
    male_company_size_details = Column(String(10000), comment='男性企業規模詳細')
    male_duration_service_years = Column(Numeric, comment='男性平均継続勤務年数')
    male_childcare_leave_num = Column(BigInteger, comment='男性育児休業対象者数')
    male_childcare_leave_taking_num = Column(BigInteger, comment='男性育児休業取得者数')
    female_company_size_details = Column(String(10000), comment='女性企業規模詳細')
    female_duration_service_years = Column(Numeric, comment='女性平均継続勤務年数')
    female_childcare_leave_num = Column(BigInteger, comment='女性育児休業取得者数')
    female_childcare_leave_taking_num = Column(
        BigInteger, comment='女性育児休業対象者数')
    female_managers_num = Column(BigInteger, comment='女性管理職人数')
    female_officers_num = Column(BigInteger, comment='女性役員人数')
    female_workers_pct = Column(Numeric, comment='労働者に占める女性労働者の割合')
    female_workers_pct_class_type = Column(
        String(1), comment='労働者に占める女性労働者の割合種別区分')
    females_managerial_pct = Column(Numeric, comment='管理職に占める女性の割合')
    last_updated_date = Column(DateTime, comment='最終更新日時')
    successor_is_exist = Column(Boolean, comment='後継者有無フラグ')
    delegate_app_num = Column(String(15), comment='委任申請番号')
    target_service_code = Column(String(5), comment='対象サービスコード')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')


class NerworkBuildType(CommonModel):
    __tablename__ = 'nerwork_build_types'
    __table_args__ = {'comment': 'ネットワーク構築状況区分'}

    type_code = Column(String(2), primary_key=True, comment='状況コード')
    type_name = Column(String(255), comment='状況名称')


class PrefCode(CommonModel):
    __tablename__ = 'pref_codes'
    __table_args__ = {'comment': '都道府県コード'}

    pref_code = Column(String(2), primary_key=True, comment='都道府県コード')
    pref_name = Column(String(255), comment='都道府県名称')


class ProceduretType(CommonModel):
    __tablename__ = 'proceduret_types'
    __table_args__ = {'comment': '手続き種別'}

    proceduret_type_code = Column(
        String(2), primary_key=True, comment='手続き種別コード')
    proceduret_type_name = Column(String(255), comment='手続き種別名称')


class QualCode(CommonModel):
    __tablename__ = 'qual_codes'
    __table_args__ = {'comment': '資格コードマスタ'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('qual_codes_id_seq'::regclass)"), comment='ID')
    qual_code = Column(Integer, nullable=False, comment='資格コード')
    qual_name = Column(String(255), comment='資格名称')


class SmallIndustryCode(CommonModel):
    __tablename__ = 'small_industry_codes'
    __table_args__ = {'comment': '業種小分類'}

    small_industry_code = Column(
        String(3), primary_key=True, comment='業種小分類コード')
    small_industry_name = Column(String(255), comment='業種小分類名称')


class Subsidy(CommonModel):
    __tablename__ = 'subsidies'
    __table_args__ = {'comment': '補助金制度'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('subsidies_id_seq'::regclass)"), comment='ID')
    subsidy_id = Column(String(18), nullable=False,
                        unique=True, comment='補助金ID')
    subsidy_name = Column(String(255), comment='補助金名称')
    subsidy_title = Column(String(100), comment='補助金タイトル')
    subsidy_num = Column(String(18), comment='補助金番号')
    subsidy_catch_phrase = Column(String(10000), comment='補助金のキャッチコピー')
    subsidy_amt = Column(String(10000), comment='補助金金額')
    subsidy_former_ministry_code = Column(String(5), comment='補助金元府省コード')
    subsidy_funding = Column(String(10000), comment='補助金財源')
    subsidy_target = Column(String(10000), comment='補助金対象')
    subsidy_etc = Column(String(10000), comment='補助金等')
    subsidy_joint_name = Column(String(80), comment='補助金連名')
    subsidy_target_area = Column(String(10000), comment='補助対象地域')
    subsidy_target_area_details = Column(String(10000), comment='補助対象地域詳細')
    subsidy_maximum_amt = Column(Numeric, comment='補助上限金額')
    subsidy_rct_start_date = Column(DateTime, comment='募集開始日時')
    subsidy_rct_end_date = Column(DateTime, comment='募集終了日時')
    subsidy_employees_num_type = Column(String(2), comment='補助対象従業員数区分')
    subsidy_auxiliary_use_purpose = Column(String(10000), comment='補助利用目的')
    subsidy_industry = Column(String(10000), comment='補助対象業種')
    subsidy_rate = Column(Numeric, comment='補助率')
    biz_end_deadline = Column(Date, comment='事業終了期限')
    subsidy_biz_url = Column(String(2000), comment='事業者向け補助金詳細画面URL')
    open_call_participants = Column(String(10000), comment='公募要領')
    delivery_outline = Column(String(10000), comment='交付要綱')
    subsidy_end_date = Column(DateTime, comment='事業終了年月日')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')


class SubsidiesFileType(CommonModel):
    __tablename__ = 'subsidies_file_types'
    __table_args__ = {'comment': '補助金制度ファイル区分'}

    subsidies_file_type_code = Column(
        String(2), primary_key=True, comment='補助金制度ファイル区分コード')
    subsidies_file_type_name = Column(String(255), comment='補助金制度ファイル区分名称')


class SubsidyEmployeesNumType(CommonModel):
    __tablename__ = 'subsidy_employees_num_types'
    __table_args__ = {'comment': '補助対象従業員数区分'}

    subsidy_employees_num_type_code = Column(
        String(1), primary_key=True, comment='補助対象従業員数区分コード')
    subsidy_employees_num_type_name = Column(
        String(255), comment='補助対象従業員数区分名称')


class SupportAgencyType(CommonModel):
    __tablename__ = 'support_agency_types'
    __table_args__ = {'comment': '支援機関属性区分'}

    support_agency_type_code = Column(
        String(2), primary_key=True, comment='支援機関属性区分コード')
    support_agency_type_name = Column(String(255), comment='支援機関属性区分名称')


class SupportAgency(CommonModel):
    __tablename__ = 'support_agencys'
    __table_args__ = {'comment': '支援機関'}

    support_agency_code = Column(
        String(12), primary_key=True, comment='支援機関コード')
    support_agency_name = Column(String(50), comment='支援機関名称')
    support_agency_name_kana = Column(String(50), comment='支援機関カナ名称')
    support_agency_branch_name = Column(String(50), comment='支援機関支店名称')
    support_agency_branch_name_kana = Column(String(50), comment='支援機関支店カナ名称')
    person_chg_role = Column(String(255), comment='担当者役職')
    person_chg_last_name = Column(String(30), comment='担当者氏名（姓）')
    person_chg_kana_last_name = Column(String(30), comment='担当者カナ氏名（姓）')
    person_chg_first_name = Column(String(30), comment='担当者氏名（名）')
    person_chg_first_kana_name = Column(String(30), comment='担当者カナ氏名（名）')
    support_agency_type = Column(Integer, comment='支援機関属性区分')
    accredited_support_agency_type = Column(Integer, comment='認定支援機関区分')
    regional_platform = Column(Boolean, comment='地域プラットフォーム区分')
    support_agency_feature = Column(String(10000), comment='支援機関特徴・分野')
    support_agency_staff_num = Column(Integer, comment='支援機関専門家数')
    ceterite_type = Column(Boolean, comment='サテライト・出張相談会協力区分')
    ceterite_achievement_frequency = Column(String(50), comment='サテライト等実績頻度')
    network_type = Column(Boolean, comment='ネットワーク構築対象機関区分')
    network_status_type = Column(Boolean, comment='ネットワーク構築状況区分')
    network_constr_completion_date = Column(Date, comment='ネットワーク構築完了年月日')
    support_staff_last_name = Column(String(30), comment='支援機関担当者漢字氏名（姓）')
    support_staff_kana_last_name = Column(String(30), comment='支援機関担当者カナ氏名（姓）')
    support_staff_first_name = Column(String(30), comment='支援機関担当者漢字氏名（名）')
    support_staff_first_kana_name = Column(
        String(30), comment='支援機関担当者カナ氏名（名）')
    support_staff_department = Column(String(20), comment='支援機関担当者所属部署')
    support_staff_role = Column(String(255), comment='支援機関担当者役職')
    support_staff_qual = Column(String(10000), comment='支援機関担当者資格')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')


class SupportType(CommonModel):
    __tablename__ = 'support_types'
    __table_args__ = {'comment': '支援区分'}

    support_type_code = Column(String(2), primary_key=True, comment='支援区分コード')
    support_type_name = Column(String(255), comment='支援区分名称')


class SystemIndividualAttachmentFileCategoryCode(CommonModel):
    __tablename__ = 'system_individual_attachment_file_category_codes'
    __table_args__ = {'comment': '制度個別添付ファイルカテゴリ'}

    system_Individual__attachment_file_category_code = Column(
        'system_Individual _attachment_file_category_code', String(2), primary_key=True, comment='制度個別添付ファイルカテゴリコード')
    system_Individual__attachment_file_category_name = Column(
        'system_Individual _attachment_file_category_name', String(255), comment='制度個別添付ファイルカテゴリ名称')


class SystemResultType(CommonModel):
    __tablename__ = 'system_result_types'
    __table_args__ = {'comment': '制度結果区分'}

    system_result_type_code = Column(
        String(2), primary_key=True, comment='制度結果区分コード')
    system_result_type_name = Column(String(255), comment='制度結果区分名称')


class Award(CommonModel):
    __tablename__ = 'awards'
    __table_args__ = {'comment': '表彰'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('awards_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    award_date = Column(Date, comment='表彰年月日')
    award_category_name = Column(String(80), comment='表彰部門名称')
    awards_former_ministry_code = Column(String(5), comment='表彰元府省コード')
    award_target = Column(String(10000), comment='受賞対象')
    award_name = Column(String(50), comment='表彰名称')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class BasicApp(CommonModel):
    __tablename__ = 'basic_apps'
    __table_args__ = {'comment': '申請基本情報'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('basic_apps_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    subsidy_app_num = Column(String(255), nullable=False,
                             comment='補助金申請番号:08_申請事業内容')
    subsidy_id = Column(ForeignKey('subsidies.subsidy_id'), ForeignKey(
        'subsidies.subsidy_id'), nullable=False, comment='補助金ID:08_申請事業内容')
    app_date = Column(Date, comment='申請年月日:08_申請事業内容')
    subsidy_name = Column(String(100), comment='補助金制度名')
    subsidy_year = Column(String(4), comment='補助金年度')
    subsidy_number = Column(BigInteger, comment='補助金公募回')
    subsidy_area = Column(String(100), comment='管轄地域')
    result_type = Column(String(2), comment='結果区分')
    result_date = Column(Date, comment='申請結果決定日')
    proceduret_type = Column(String(2), comment='手続き種別')
    biz_name = Column(String(100), comment='事業名称:08_申請事業内容')
    biz_purpose_desc = Column(String(10000), comment='事業目的記述:08_申請事業内容')
    biz_desc = Column(String(10000), comment='事業内容記述:08_申請事業内容')
    scheduled_biz_start_date = Column(Date, comment='事業開始予定年月日:02_事業計画')
    scheduled_biz_end_date = Column(Date, comment='事業開始終了年月日:02_事業計画')
    app_person_last_name = Column(String(30), comment='申請担当者漢字氏名（姓）:05_担当者情報')
    app_person_kana_last_name = Column(
        String(30), comment='申請担当者カナ氏名（姓）:05_担当者情報')
    app_person_first_name = Column(String(30), comment='申請担当者漢字氏名（名）:05_担当者情報')
    app_person_kana_first_name = Column(
        String(30), comment='申請担当者カナ氏名（名）:05_担当者情報')
    app_person_role = Column(String(255), comment='申請担当者役職名称:05_担当者情報')
    app_person_pref_code = Column(
        String(2), comment='申請担当者連絡先住所都道府県コード:05_担当者情報')
    app_person_add_city_name = Column(
        String(100), comment='申請担当者連絡先住所町名（郡・市区町村～町名）:05_担当者情報')
    app_person_add_street = Column(
        String(100), comment='申請担当者連絡先住所丁目以下:05_担当者情報')
    app_person_add_suburb = Column(
        String(100), comment='申請担当者連絡先住所建物名等:05_担当者情報')
    app_person_add_post_code = Column(
        String(7), comment='申請担当者連絡先郵便番号:05_担当者情報')
    app_person_email_address = Column(
        String(255), comment='申請担当者連絡先メールアドレス:05_担当者情報')
    app_person_web_form_url = Column(
        String(2000), comment='申請担当者連絡先WebフォームURL:05_担当者情報')
    app_person_phone_num = Column(String(20), comment='申請担当者連絡先電話番号:05_担当者情報')
    contact_department_name = Column(
        String(200), comment='申請担当者連絡先部署名称:05_担当者情報')
    app_person_birth = Column(Date, comment='申請担当者生年月日:05_担当者情報')
    app_person_affiliation_org_name = Column(
        String(80), comment='申請担当者所属組織名称:05_担当者情報')
    biz_type_type = Column(String(2), comment='事業形態区分:08_申請事業内容')
    biz_scale_type = Column(String(2), comment='事業規模区分:08_申請事業内容')
    project_imple_schedule = Column(
        String(10000), comment='事業実施スケジュール:02_事業計画')
    biz_imple_system = Column(String(10000), comment='事業実施体制:08_申請事業内容')
    biz_effect_desc = Column(String(10000), comment='事業効果記述:08_申請事業内容')
    file_path = Column(String(255), comment='該当添付ファイル')
    updated_at = Column(TIMESTAMP(precision=6), nullable=False,
                        server_default=text("CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(TIMESTAMP(precision=6), nullable=False,
                        server_default=text("CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')
    subsidy = relationship(
        'Subsidy', primaryjoin='BasicApp.subsidy_id == Subsidy.subsidy_id')
    subsidy1 = relationship(
        'Subsidy', primaryjoin='BasicApp.subsidy_id == Subsidy.subsidy_id')


class BizAreaCode(CommonModel):
    __tablename__ = 'biz_area_codes'
    __table_args__ = {'comment': '法人基本情報_営業エリアコード'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('biz_area_codes_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    biz_area_code = Column(String(2), comment='営業エリアコード')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class BizItemCode(CommonModel):
    __tablename__ = 'biz_item_codes'
    __table_args__ = {'comment': '法人基本情報_営業項目コード'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('biz_item_codes_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    biz_item_code = Column(String(3), comment='営業項目コード')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class Certification(CommonModel):
    __tablename__ = 'certifications'
    __table_args__ = {'comment': '届出・認定'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('certifications_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    cert_date = Column(Date, comment='認定年月日')
    notice_cert_department_name = Column(String(255), comment='届出・認定部門名称')
    notice_cert_expiration_date = Column(DateTime, comment='届出・認定有効期限年月日')
    notice_cert_ministry_code = Column(String(5), comment='届出・認定府省コード')
    notice_cert_target = Column(String(10000), comment='届出・認定対象')
    notice_cert_etc = Column(String(10000), comment='届出認定等')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class Credential(CommonModel):
    __tablename__ = 'credentials'
    __table_args__ = {'comment': '資格'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('credentials_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    qual_code = Column(BigInteger, comment='資格コード')
    qual_jurisdiction_group_registration_num = Column(
        String(50), comment='資格所管団体登録番号')
    qual_holder_last_name = Column(String(30), comment='資格保有者漢字氏名（姓）')
    qual_holder_kana_last_name = Column(String(30), comment='資格保有者カナ氏名（姓）')
    qual_holder_first_name = Column(String(30), comment='資格保有者漢字氏名（名）')
    qual_holder_kana_first_name = Column(String(30), comment='資格保有者カナ氏名（名）')
    qual_holder_date_of_birth = Column(Date, comment='資格保有者生年月日')
    qual_registration_date = Column(Date, comment='資格登録年月日')
    qual_expiration_date = Column(Date, comment='資格有効期限年月日')
    qual_owner_office_name = Column(String(80), comment='資格所有者所属事業所名称')
    qual_owner_office_add_pref_code = Column(
        String(2), comment='資格所有者所属事業所住所都道府県コード')
    qual_owner_office_add_city = Column(
        String(100), comment='資格所有者所属事業所住所町名（郡・市区町村～町名）')
    qual_owner_office_add_street = Column(
        String(100), comment='資格所有者所属事業所住所丁目以下')
    qual_owner_office_add_suburb = Column(
        String(100), comment='資格所有者所属事業所住所建物名等')
    qual_owner_office_add_post_code = Column(
        String(7), comment='資格所有者所属事業所郵便番号')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class DefaultDisclosureAuth(CommonModel):
    __tablename__ = 'default_disclosure_auth'
    __table_args__ = {'comment': '初期公開権限:初期の公開権限設定'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('\"$$default_disclosure_auth_id_seq\"'::regclass)"), comment='ID')
    category_code = Column(String(2), comment='カテゴリコード')
    approval_group_code = Column(ForeignKey(
        'groups.support_agency_group_code'), nullable=False, comment='開示先グループコード')
    is_open = Column(Boolean, comment='公開設定:公開;非公開;指定なし')

    group = relationship('Group')


class Finance(CommonModel):
    __tablename__ = 'finances'
    __table_args__ = {'comment': '財務状況'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('finances_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    accounting_standard = Column(String(100), comment='会計基準')
    fiscal_year_cover_page = Column(String(100), comment='会計期')
    target_year_settlement_date = Column(Date, comment='対象年度決算年月日')
    capital_amt = Column(Numeric, comment='資本金')
    capital_reserve = Column(Numeric, comment='資本準備金額')
    asset_amt = Column(Numeric, comment='資産金額')
    debt_amt = Column(Numeric, comment='負債金額')
    total_capital_amt = Column(Numeric, comment='総資本金額')
    equity_amt = Column(Numeric, comment='自己資本金額')
    net_worth = Column(Numeric, comment='純資産金額')
    current_asset_amt = Column(Numeric, comment='流動資産金額')
    current_liability_amt = Column(Numeric, comment='流動負債金額')
    other_current_assets_amt = Column(Numeric, comment='その他流動資産金額')
    other_current_liability_amt = Column(Numeric, comment='その他流動負債金額')
    inventories_amt = Column(Numeric, comment='棚卸資産金額')
    fixed_asset_amt = Column(Numeric, comment='固定資産金額')
    prop_plant_and_equipment_amt = Column(Numeric, comment='有形固定資産金額')
    land_valuation_amt = Column(Numeric, comment='土地評価金額')
    building_valuation_amt = Column(Numeric, comment='建物評価金額')
    machinery_equipment_evaluation_amt = Column(Numeric, comment='機械・装置評価金額')
    vehicle_carrier_evaluation_amt = Column(Numeric, comment='車両運搬具評価金額')
    intangible_assets_amt = Column(Numeric, comment='無形固定資産金額')
    other_fixed_asset_amt = Column(Numeric, comment='その他固定資産金額')
    fixed_liabilities_amt = Column(Numeric, comment='固定負債金額')
    cash_and_deposit_amt = Column(Numeric, comment='現金及び預金金額')
    bills_receivable = Column(Numeric, comment='受取手形金額')
    bills_payable = Column(Numeric, comment='支払手形金額')
    accounts_payable = Column(Numeric, comment='買掛金金額')
    accounts_receivable = Column(Numeric, comment='売掛金金額')
    prepaid_payment_amt = Column(Numeric, comment='前払金金額')
    accounts_payable_amt = Column(Numeric, comment='未払金金額')
    advance_payment_amt = Column(Numeric, comment='前受金金額')
    borrowing_amt = Column(Numeric, comment='借入金金額')
    securities_amt = Column(Numeric, comment='有価証券金額')
    loan_amt = Column(Numeric, comment='貸付金金額')
    short_term_loan_amt = Column(Numeric, comment='短期貸付金金額')
    allowance_doubtful_accounts_amt = Column(Numeric, comment='貸倒引当金金額')
    short_term_borrowing_amt = Column(Numeric, comment='短期借入金金額')
    long_term_borrowing_amt = Column(Numeric, comment='長期借入金金額')
    deposit_amt = Column(Numeric, comment='預り金金額')
    sales_amt = Column(Numeric, comment='売上高金額')
    cost_of_sales = Column(Numeric, comment='売上原価金額')
    depr_within_cost_sales = Column(BigInteger, comment='売上原価内減価償却費')
    profit_margin_amt = Column(Numeric, comment='売上総利益金額')
    labor_cost = Column(BigInteger, comment='労務費')
    selling_general_admin_expenses = Column(BigInteger, comment='販売費及び一般管理費')
    depr_within_sg_and_a = Column(BigInteger, comment='販管費内減価償却費')
    labor_costs = Column(BigInteger, comment='人件費')
    total_operating_revenue = Column(Numeric, comment='営業総収入金額')
    operating_income_amt = Column(Numeric, comment='営業収入金額')
    operating_profit_amt = Column(Numeric, comment='営業利益金額')
    operating_revenue_amt = Column(Numeric, comment='営業収益金額')
    non_operating_income_amt = Column(Numeric, comment='営業外収益金額')
    non_operating_expenses_amt = Column(Numeric, comment='営業外費用金額')
    ordinary_profit_amt = Column(Numeric, comment='経常利益金額')
    ordinary_loss_amt = Column(Numeric, comment='経常損失金額')
    extraordinary_profit_amt = Column(Numeric, comment='特別利益金額')
    extraordinary_loss_amt = Column(Numeric, comment='特別損失金額')
    net_profit_amt = Column(Numeric, comment='純利益金額')
    net_income_before_tax = Column(Numeric, comment='税引前純利益金額')
    net_loss_amt = Column(Numeric, comment='純損失金額')
    cost_amt = Column(Numeric, comment='原価金額')
    depr_amt = Column(Numeric, comment='減価償却費金額')
    net_premiums_written = Column(Numeric, comment='正味収入保険料')
    gross_profit_amt = Column(Numeric, comment='粗利益金額')
    retained_earnings = Column(Numeric, comment='利益剰余金額')
    retained_earnings_carried_forward = Column(Numeric, comment='繰越利益剰余金額')
    current_ratio = Column(Numeric, comment='流動比率')
    capital_adequacy_ratio = Column(Numeric, comment='自己資本比率')
    added_value_amt = Column(Numeric, comment='付加価値額')
    labor_prodivity_ratio = Column(Numeric, comment='労働生産性比率')
    biz_applicable_corp_is_oath = Column(Boolean, comment='本事業該当法人宣誓フラグ')
    self_financing_person_name = Column(String(60), comment='自己資金負担者名称')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class GepsShikakuType(CommonModel):
    __tablename__ = 'geps_shikaku_types'
    __table_args__ = {'comment': '法人基本情報_政府統一参加資格（物品調達）区分'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('geps_shikaku_types_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    geps_shikaku_type = Column(String(1), comment='政府統一参加資格（物品調達）区分')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class IntellectualProperty(CommonModel):
    __tablename__ = 'intellectual_properties'
    __table_args__ = {'comment': '保有知的財産'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('intellectual_properties_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    intellectual_prop_app_date = Column(Date, comment='出願年月日')
    intellectual_prop_type = Column(String(50), comment='知的財産権区分')
    intellectual_prop_app_type = Column(String(2), comment='出願分類')
    intellectual_prop_app_num = Column(String(10), comment='知的財産権出願番号')
    trademark_for_display = Column(String(100), comment='表示用商標')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class LocabenNonFinancialStatus(CommonModel):
    __tablename__ = 'locaben_non_financial_statuses'
    __table_args__ = {'comment': 'ローカルベンチマーク非財務状況'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('locaben_non_financial_statuses_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    management_philosophy = Column(String(10000), comment='経営理念')
    management_motivation = Column(String(10000), comment='経営意欲')
    corp_biz_history = Column(String(10000), comment='企業及び事業沿革')
    tech_and_sales_strengths = Column(String(10000), comment='技術力・販売力の強み')
    tech_and_sales_weaknesses = Column(String(10000), comment='技術力・販売力の弱み')
    it_investment_utilization_status = Column(
        String(10000), comment='IT投資活用状況')
    market_trend = Column(String(10000), comment='市場動向')
    understanding_scale_and_share = Column(String(10000), comment='規模・シェアの把握')
    comparison_with_competitors = Column(String(10000), comment='競合他社との比較')
    customer_repeat_rate = Column(Numeric, comment='顧客リピート率')
    new_dev_rate = Column(Numeric, comment='新規開拓率')
    major_biz_partners_changes = Column(String(10000), comment='主な取引先推移')
    customer_feedback_is_exist = Column(Boolean, comment='顧客フィードバックの有無フラグ')
    employee_retention_rate = Column(Numeric, comment='従業員定着率')
    avg_years_of_service = Column(Numeric, comment='平均勤続年数')
    avg_salary = Column(Numeric, comment='平均給与金額')
    financial_institutions_num = Column(BigInteger, comment='取引金融機関数')
    financial_institutions_num_changes = Column(
        String(10000), comment='取引金融機関数の推移')
    relation_main_bank = Column(String(10000), comment='メインバンクとの関係')
    quality_control_system = Column(String(10000), comment='品質管理体制')
    info_management_system = Column(String(10000), comment='情報管理体制')
    biz_plan_is_exist = Column(Boolean, comment='事業計画・経営計画の有無フラグ')
    biz_plan_employees_sharing_status = Column(
        String(10000), comment='事業計画・経営計画の従業員との共有状況')
    internal_meetings_status = Column(String(10000), comment='社内会議の実施状況')
    r_d_prod_dev_system = Column(String(10000), comment='研究開発・商品開発体制')
    intellectual_prop_rights_status = Column(
        String(10000), comment='知的財産権の保有・活用状況')
    hr_dev_effortsstatus = Column(String(10000), comment='人財育成取組状況')
    hr_dev_mechanism = Column(String(10000), comment='人財育成の仕組み')
    current_situation_recognition = Column(String(10000), comment='現状認識')
    future_goals = Column(String(10000), comment='将来目標')
    future_goals_achieving = Column(String(10000), comment='将来目標達成の課題')
    countermeasures_issues = Column(String(10000), comment='課題への対応策')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class MstAward(CommonModel):
    __tablename__ = 'mst_awards'
    __table_args__ = {'comment': '[マスタ]表彰'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_awards_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    award_date = Column(Date, comment='表彰年月日')
    award_category_name = Column(String(80), comment='表彰部門名称')
    awards_former_ministry_code = Column(String(5), comment='表彰元府省コード')
    award_target = Column(String(10000), comment='受賞対象')
    award_name = Column(String(50), comment='表彰名称')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstBizAreaCode(CommonModel):
    __tablename__ = 'mst_biz_area_codes'
    __table_args__ = {'comment': '[マスタ]法人基本情報_営業エリアコード'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_biz_area_codes_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    biz_area_code = Column(String(2), comment='営業エリアコード')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstBizItemCode(CommonModel):
    __tablename__ = 'mst_biz_item_codes'
    __table_args__ = {'comment': '[マスタ]法人基本情報_営業項目コード'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_biz_item_codes_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    biz_item_code = Column(String(3), comment='営業項目コード')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstCertification(CommonModel):
    __tablename__ = 'mst_certifications'
    __table_args__ = {'comment': '[マスタ]届出・認定'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_certifications_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    cert_date = Column(Date, comment='認定年月日')
    notice_cert_department_name = Column(String(255), comment='届出・認定部門名称')
    notice_cert_expiration_date = Column(DateTime, comment='届出・認定有効期限年月日')
    notice_cert_ministry_code = Column(String(5), comment='届出・認定府省コード')
    notice_cert_target = Column(String(10000), comment='届出・認定対象')
    notice_cert_etc = Column(String(10000), comment='届出認定等')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstCredential(CommonModel):
    __tablename__ = 'mst_credentials'
    __table_args__ = {'comment': '[マスタ]資格'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_credentials_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    qual_code = Column(BigInteger, comment='資格コード')
    qual_jurisdiction_group_registration_num = Column(
        String(50), comment='資格所管団体登録番号')
    qual_holder_last_name = Column(String(30), comment='資格保有者漢字氏名（姓）')
    qual_holder_kana_last_name = Column(String(30), comment='資格保有者カナ氏名（姓）')
    qual_holder_first_name = Column(String(30), comment='資格保有者漢字氏名（名）')
    qual_holder_kana_first_name = Column(String(30), comment='資格保有者カナ氏名（名）')
    qual_holder_date_of_birth = Column(Date, comment='資格保有者生年月日')
    qual_registration_date = Column(Date, comment='資格登録年月日')
    qual_expiration_date = Column(Date, comment='資格有効期限年月日')
    qual_owner_office_name = Column(String(80), comment='資格所有者所属事業所名称')
    qual_owner_office_add_pref_code = Column(
        String(2), comment='資格所有者所属事業所住所都道府県コード')
    qual_owner_office_add_city = Column(
        String(100), comment='資格所有者所属事業所住所町名（郡・市区町村～町名）')
    qual_owner_office_add_street = Column(
        String(100), comment='資格所有者所属事業所住所丁目以下')
    qual_owner_office_add_suburb = Column(
        String(100), comment='資格所有者所属事業所住所建物名等')
    qual_owner_office_add_post_code = Column(
        String(7), comment='資格所有者所属事業所郵便番号')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstFinance(CommonModel):
    __tablename__ = 'mst_finances'
    __table_args__ = {'comment': '[マスタ]財務状況'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_finances_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    accounting_standard = Column(String(100), comment='会計基準')
    fiscal_year_cover_page = Column(String(100), comment='会計期')
    target_year_settlement_date = Column(Date, comment='対象年度決算年月日')
    capital_amt = Column(Numeric, comment='資本金')
    capital_reserve = Column(Numeric, comment='資本準備金額')
    asset_amt = Column(Numeric, comment='資産金額')
    debt_amt = Column(Numeric, comment='負債金額')
    total_capital_amt = Column(Numeric, comment='総資本金額')
    equity_amt = Column(Numeric, comment='自己資本金額')
    net_worth = Column(Numeric, comment='純資産金額')
    current_asset_amt = Column(Numeric, comment='流動資産金額')
    current_liability_amt = Column(Numeric, comment='流動負債金額')
    other_current_assets_amt = Column(Numeric, comment='その他流動資産金額')
    other_current_liability_amt = Column(Numeric, comment='その他流動負債金額')
    inventories_amt = Column(Numeric, comment='棚卸資産金額')
    fixed_asset_amt = Column(Numeric, comment='固定資産金額')
    prop_plant_and_equipment_amt = Column(Numeric, comment='有形固定資産金額')
    land_valuation_amt = Column(Numeric, comment='土地評価金額')
    building_valuation_amt = Column(Numeric, comment='建物評価金額')
    machinery_equipment_evaluation_amt = Column(Numeric, comment='機械・装置評価金額')
    vehicle_carrier_evaluation_amt = Column(Numeric, comment='車両運搬具評価金額')
    intangible_assets_amt = Column(Numeric, comment='無形固定資産金額')
    other_fixed_asset_amt = Column(Numeric, comment='その他固定資産金額')
    fixed_liabilities_amt = Column(Numeric, comment='固定負債金額')
    cash_and_deposit_amt = Column(Numeric, comment='現金及び預金金額')
    bills_receivable = Column(Numeric, comment='受取手形金額')
    bills_payable = Column(Numeric, comment='支払手形金額')
    accounts_payable = Column(Numeric, comment='買掛金金額')
    accounts_receivable = Column(Numeric, comment='売掛金金額')
    prepaid_payment_amt = Column(Numeric, comment='前払金金額')
    accounts_payable_amt = Column(Numeric, comment='未払金金額')
    advance_payment_amt = Column(Numeric, comment='前受金金額')
    borrowing_amt = Column(Numeric, comment='借入金金額')
    securities_amt = Column(Numeric, comment='有価証券金額')
    loan_amt = Column(Numeric, comment='貸付金金額')
    short_term_loan_amt = Column(Numeric, comment='短期貸付金金額')
    allowance_doubtful_accounts_amt = Column(Numeric, comment='貸倒引当金金額')
    short_term_borrowing_amt = Column(Numeric, comment='短期借入金金額')
    long_term_borrowing_amt = Column(Numeric, comment='長期借入金金額')
    deposit_amt = Column(Numeric, comment='預り金金額')
    sales_amt = Column(Numeric, comment='売上高金額')
    cost_of_sales = Column(Numeric, comment='売上原価金額')
    depr_within_cost_sales = Column(BigInteger, comment='売上原価内減価償却費')
    profit_margin_amt = Column(Numeric, comment='売上総利益金額')
    labor_cost = Column(BigInteger, comment='労務費')
    selling_general_admin_expenses = Column(BigInteger, comment='販売費及び一般管理費')
    depr_within_sg_and_a = Column(BigInteger, comment='販管費内減価償却費')
    labor_costs = Column(BigInteger, comment='人件費')
    total_operating_revenue = Column(Numeric, comment='営業総収入金額')
    operating_income_amt = Column(Numeric, comment='営業収入金額')
    operating_profit_amt = Column(Numeric, comment='営業利益金額')
    operating_revenue_amt = Column(Numeric, comment='営業収益金額')
    non_operating_income_amt = Column(Numeric, comment='営業外収益金額')
    non_operating_expenses_amt = Column(Numeric, comment='営業外費用金額')
    ordinary_profit_amt = Column(Numeric, comment='経常利益金額')
    ordinary_loss_amt = Column(Numeric, comment='経常損失金額')
    extraordinary_profit_amt = Column(Numeric, comment='特別利益金額')
    extraordinary_loss_amt = Column(Numeric, comment='特別損失金額')
    net_profit_amt = Column(Numeric, comment='純利益金額')
    net_income_before_tax = Column(Numeric, comment='税引前純利益金額')
    net_loss_amt = Column(Numeric, comment='純損失金額')
    cost_amt = Column(Numeric, comment='原価金額')
    depr_amt = Column(Numeric, comment='減価償却費金額')
    net_premiums_written = Column(Numeric, comment='正味収入保険料')
    gross_profit_amt = Column(Numeric, comment='粗利益金額')
    retained_earnings = Column(Numeric, comment='利益剰余金額')
    retained_earnings_carried_forward = Column(Numeric, comment='繰越利益剰余金額')
    current_ratio = Column(Numeric, comment='流動比率')
    capital_adequacy_ratio = Column(Numeric, comment='自己資本比率')
    added_value_amt = Column(Numeric, comment='付加価値額')
    labor_prodivity_ratio = Column(Numeric, comment='労働生産性比率')
    biz_applicable_corp_is_oath = Column(Boolean, comment='本事業該当法人宣誓フラグ')
    self_financing_person_name = Column(String(60), comment='自己資金負担者名称')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstGepsShikakuType(CommonModel):
    __tablename__ = 'mst_geps_shikaku_types'
    __table_args__ = {'comment': '[マスタ]法人基本情報_政府統一参加資格（物品調達）区分'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_geps_shikaku_types_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    geps_shikaku_type = Column(String(1), comment='政府統一参加資格（物品調達）区分')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstIntellectualProperty(CommonModel):
    __tablename__ = 'mst_intellectual_properties'
    __table_args__ = {'comment': '[マスタ]保有知的財産'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_intellectual_properties_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    intellectual_prop_app_date = Column(Date, comment='出願年月日')
    intellectual_prop_type = Column(String(50), comment='知的財産権区分')
    intellectual_prop_app_type = Column(String(2), comment='出願分類')
    intellectual_prop_app_num = Column(String(10), comment='知的財産権出願番号')
    trademark_for_display = Column(String(100), comment='表示用商標')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstLocabenNonFinancialStatus(CommonModel):
    __tablename__ = 'mst_locaben_non_financial_statuses'
    __table_args__ = {'comment': '[マスタ]ローカルベンチマーク非財務状況'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_locaben_non_financial_statuses_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    management_philosophy = Column(String(10000), comment='経営理念')
    management_motivation = Column(String(10000), comment='経営意欲')
    corp_biz_history = Column(String(10000), comment='企業及び事業沿革')
    tech_and_sales_strengths = Column(String(10000), comment='技術力・販売力の強み')
    tech_and_sales_weaknesses = Column(String(10000), comment='技術力・販売力の弱み')
    it_investment_utilization_status = Column(
        String(10000), comment='IT投資活用状況')
    market_trend = Column(String(10000), comment='市場動向')
    understanding_scale_and_share = Column(String(10000), comment='規模・シェアの把握')
    comparison_with_competitors = Column(String(10000), comment='競合他社との比較')
    customer_repeat_rate = Column(Numeric, comment='顧客リピート率')
    new_dev_rate = Column(Numeric, comment='新規開拓率')
    major_biz_partners_changes = Column(String(10000), comment='主な取引先推移')
    customer_feedback_is_exist = Column(Boolean, comment='顧客フィードバックの有無フラグ')
    employee_retention_rate = Column(Numeric, comment='従業員定着率')
    avg_years_of_service = Column(Numeric, comment='平均勤続年数')
    avg_salary = Column(Numeric, comment='平均給与金額')
    financial_institutions_num = Column(BigInteger, comment='取引金融機関数')
    financial_institutions_num_changes = Column(
        String(10000), comment='取引金融機関数の推移')
    relation_main_bank = Column(String(10000), comment='メインバンクとの関係')
    quality_control_system = Column(String(10000), comment='品質管理体制')
    info_management_system = Column(String(10000), comment='情報管理体制')
    biz_plan_is_exist = Column(Boolean, comment='事業計画・経営計画の有無フラグ')
    biz_plan_employees_sharing_status = Column(
        String(10000), comment='事業計画・経営計画の従業員との共有状況')
    internal_meetings_status = Column(String(10000), comment='社内会議の実施状況')
    r_d_prod_dev_system = Column(String(10000), comment='研究開発・商品開発体制')
    intellectual_prop_rights_status = Column(
        String(10000), comment='知的財産権の保有・活用状況')
    hr_dev_effortsstatus = Column(String(10000), comment='人財育成取組状況')
    hr_dev_mechanism = Column(String(10000), comment='人財育成の仕組み')
    current_situation_recognition = Column(String(10000), comment='現状認識')
    future_goals = Column(String(10000), comment='将来目標')
    future_goals_achieving = Column(String(10000), comment='将来目標達成の課題')
    countermeasures_issues = Column(String(10000), comment='課題への対応策')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstOfficer(CommonModel):
    __tablename__ = 'mst_officers'
    __table_args__ = {'comment': '[マスタ]役員'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_officers_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    officer_card_entry_date = Column(Date, comment='役員票記入年月日')
    officer_last_name = Column(String(30), comment='役員漢字氏名（姓）')
    officer_kana_last_name = Column(String(30), comment='役員カナ氏名（姓）')
    officer_first_name = Column(String(30), comment='役員漢字氏名（名）')
    officer_kana_first_name = Column(String(30), comment='役員カナ氏名（名）')
    officer_title_desc = Column(String(10000), comment='役員役職記述')
    officer_gender = Column(String(1), comment='役員性別区分')
    officer_qual_jurisdiction_group_num = Column(
        String(50), comment='役員保有資格所管団体登録番号')
    officer_qual_registration_date = Column(Date, comment='役員保有資格登録年月日')
    officer_qual_expiration_date = Column(Date, comment='役員保有資格有効期限年月日')
    officer_qual_office_name = Column(String(80), comment='資格保有役員所属事業所名称')
    officer_birth = Column(Date, comment='役員生年月日')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstOffice(CommonModel):
    __tablename__ = 'mst_offices'
    __table_args__ = {'comment': '[マスタ]事業所'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_offices_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    office_name = Column(String(80), comment='事業所名称')
    office_add_pref_code = Column(String(2), comment='事業所住所都道府県コード')
    office_add_city = Column(String(100), comment='事業所住所町名（郡・市区町村～町名）')
    office_add_street = Column(String(100), comment='事業所住所丁目以下')
    office_add_suburb = Column(String(100), comment='事業所住所建物名等')
    office_post_code = Column(String(7), comment='事業所郵便番号')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstProcurement(CommonModel):
    __tablename__ = 'mst_procurements'
    __table_args__ = {'comment': '[マスタ]調達'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_procurements_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    proc_order_date = Column(DateTime, comment='調達受注年月日')
    proc_amt = Column(Numeric, comment='調達金額')
    proc_ministry_code = Column(String(5), comment='調達先府省コード')
    proc_joint_name = Column(String(80), comment='調達連名')
    proc_biz_name = Column(String(80), comment='調達事業名称')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstShareholder(CommonModel):
    __tablename__ = 'mst_shareholders'
    __table_args__ = {'comment': '[マスタ]主要株主'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_shareholders_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    investor_name = Column(String(100), comment='出資者名称')
    investor_kana_name = Column(String(100), comment='出資者カナ名称')
    investor_add_pref_code = Column(String(2), comment='出資者住所都道府県コード')
    investor_add_city = Column(String(100), comment='出資者住所町名（郡・市区町村～町名）')
    investor_add_street = Column(String(100), comment='出資者住所丁目以下')
    investor_add_suburb = Column(String(100), comment='出資者住所建物名等')
    investor_zip_code = Column(String(7), comment='出資者郵便番号')
    investment_ratio = Column(Numeric, comment='出資比率')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstSuccession(CommonModel):
    __tablename__ = 'mst_successions'
    __table_args__ = {'comment': '[マスタ]承継'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_successions_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    successors_dev_status = Column(String(10000), comment='後継者の育成状況')
    timing_and_relation_succession = Column(
        String(10000), comment='承継のタイミング・関係')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class MstValueCreateBizFlow(CommonModel):
    __tablename__ = 'mst_value_create_biz_flow'
    __table_args__ = {'comment': '[マスタ]価値創出業務フロー'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_value_create_biz_flow_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('mst_basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    prod_service_content = Column(String(10000), comment='製品・商品・サービス内容')
    provided_value = Column(String(10000), comment='提供価値')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('MstBasicInfo')


class Officer(CommonModel):
    __tablename__ = 'officers'
    __table_args__ = {'comment': '役員'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('officers_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    officer_card_entry_date = Column(Date, comment='役員票記入年月日')
    officer_last_name = Column(String(30), comment='役員漢字氏名（姓）')
    officer_kana_last_name = Column(String(30), comment='役員カナ氏名（姓）')
    officer_first_name = Column(String(30), comment='役員漢字氏名（名）')
    officer_kana_first_name = Column(String(30), comment='役員カナ氏名（名）')
    officer_title_desc = Column(String(10000), comment='役員役職記述')
    officer_gender = Column(String(1), comment='役員性別区分')
    officer_qual_jurisdiction_group_num = Column(
        String(50), comment='役員保有資格所管団体登録番号')
    officer_qual_registration_date = Column(Date, comment='役員保有資格登録年月日')
    officer_qual_expiration_date = Column(Date, comment='役員保有資格有効期限年月日')
    officer_qual_office_name = Column(String(80), comment='資格保有役員所属事業所名称')
    officer_birth = Column(Date, comment='役員生年月日')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class Office(CommonModel):
    __tablename__ = 'offices'
    __table_args__ = {'comment': '事業所'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('offices_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    office_name = Column(String(80), comment='事業所名称')
    office_add_pref_code = Column(String(2), comment='事業所住所都道府県コード')
    office_add_city = Column(String(100), comment='事業所住所町名（郡・市区町村～町名）')
    office_add_street = Column(String(100), comment='事業所住所丁目以下')
    office_add_suburb = Column(String(100), comment='事業所住所建物名等')
    office_post_code = Column(String(7), comment='事業所郵便番号')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class Procurement(CommonModel):
    __tablename__ = 'procurements'
    __table_args__ = {'comment': '調達'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('procurements_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    proc_order_date = Column(DateTime, comment='調達受注年月日')
    proc_amt = Column(Numeric, comment='調達金額')
    proc_ministry_code = Column(String(5), comment='調達先府省コード')
    proc_joint_name = Column(String(80), comment='調達連名')
    proc_biz_name = Column(String(80), comment='調達事業名称')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class Shareholder(CommonModel):
    __tablename__ = 'shareholders'
    __table_args__ = {'comment': '主要株主'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('shareholders_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    investor_name = Column(String(100), comment='出資者名称')
    investor_kana_name = Column(String(100), comment='出資者カナ名称')
    investor_add_pref_code = Column(String(2), comment='出資者住所都道府県コード')
    investor_add_city = Column(String(100), comment='出資者住所町名（郡・市区町村～町名）')
    investor_add_street = Column(String(100), comment='出資者住所丁目以下')
    investor_add_suburb = Column(String(100), comment='出資者住所建物名等')
    investor_zip_code = Column(String(7), comment='出資者郵便番号')
    investment_ratio = Column(Numeric, comment='出資比率')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class SubsidyFile(CommonModel):
    __tablename__ = 'subsidy_files'
    __table_args__ = {'comment': '補助金制度ファイル'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('subsidy_files_id_seq'::regclass)"), comment='ID')
    subsidie_id = Column(ForeignKey('subsidies.subsidy_id'),
                         nullable=False, comment='補助金制度ID')
    file_name = Column(String(255), comment='ファイル名')
    file_path = Column(String(255), comment='ファイルパス')
    file_category = Column(String(2), comment='ファイルカテゴリ')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    subsidie = relationship('Subsidy')


class Succession(CommonModel):
    __tablename__ = 'successions'
    __table_args__ = {'comment': '承継'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('successions_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    successors_dev_status = Column(String(10000), comment='後継者の育成状況')
    timing_and_relation_succession = Column(
        String(10000), comment='承継のタイミング・関係')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class Userinfo(CommonModel):
    __tablename__ = 'userinfo'
    __table_args__ = {'comment': 'ユーザー情報'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('userinfo_id_seq'::regclass)"), comment='ID')
    gbiz_id = Column(BigInteger, unique=True, comment='gBizID')
    mirasapoconnect_id = Column(
        String(128), unique=True, comment='ミラサポconnectID')
    account_type = Column(String(1), nullable=False, comment='アカウント種別')
    corp_type = Column(String(1), nullable=False, comment='事業形態')
    gbiz_prime_id = Column(BigInteger, comment='gbizプライムID')
    support_agency_group_code = Column(String(2), comment='支援機関グループコード')
    corporate_number = Column(ForeignKey(
        'mst_basic_infos.corp_num'), comment='法人番号;個人事業主管理番号')
    name = Column(String(2048), comment='法人名;屋号')
    en_name = Column(String(2048), comment='法人名;屋号(英語表記)')
    pref_code = Column(String(2), comment='都道府県コード')
    address1 = Column(String(64), comment='市区町村')
    address2 = Column(String(30), comment='番地')
    rep_last_nm = Column(String(64), comment='代表者名(姓)')
    rep_first_nm = Column(String(64), comment='代表者名(名)')
    rep_last_nm_kana = Column(String(64), comment='代表者名フリガナ(姓)')
    rep_first_nm_kana = Column(String(64), comment='代表者名フリガナ(名)')
    birthday_ymd = Column(String(8), comment='代表者生年月日;個人事業主生年月日')
    user_last_nm = Column(String(2048), comment='アカウント利用者氏名(姓)')
    user_first_nm = Column(String(2048), comment='アカウント利用者氏名(名)')
    user_last_nm_kana = Column(String(2048), comment='アカウント利用者氏名フリガナ(姓)')
    user_first_nm_kana = Column(String(2048), comment='アカウント利用者氏名フリガナ(名)')
    user_post_code = Column(String(7), comment='連絡先郵便番号')
    user_pref_code = Column(String(2), comment='[利用者情報]連絡先住所都道府県コード')
    user_address1 = Column(String(64), comment='[利用者情報]連絡先住所(市区町村)')
    user_address2 = Column(String(300), comment='[利用者情報]連絡先住所(マンション名等)')
    user_department = Column(String(64), comment='[利用者情報]会社部署名;部署名')
    user_tel_no_contact = Column(String(16), comment='[利用者情報]連絡先電話番号')
    user_birthday_ymd = Column(String(8), comment='[利用者情報]利用者生年月日')
    user_email = Column(String(320), comment='[利用者情報]メールアドレス')
    updated_at = Column(TIMESTAMP(precision=6), nullable=False,
                        server_default=text("CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(TIMESTAMP(precision=6), nullable=False,
                        server_default=text("CURRENT_TIMESTAMP"), comment='作成日')

    mst_basic_info = relationship('MstBasicInfo')


class ValueCreateBizFlow(CommonModel):
    __tablename__ = 'value_create_biz_flow'
    __table_args__ = {'comment': '価値創出業務フロー'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('value_create_biz_flow_id_seq'::regclass)"), comment='ID')
    basic_info_id = Column(ForeignKey('basic_infos.id'),
                           nullable=False, comment='法人基本情報ID')
    prod_service_content = Column(String(10000), comment='製品・商品・サービス内容')
    provided_value = Column(String(10000), comment='提供価値')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_info = relationship('BasicInfo')


class ApprovalRequestInfo(CommonModel):
    __tablename__ = 'approval_request_info'
    __table_args__ = {'comment': '承認依頼情報:法人情報の開示依頼の情報'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('approval_request_info_id_seq'::regclass)"), comment='ID')
    approval_corp_num = Column(String(13), nullable=False, comment='承認者法人番号')
    request_user_id = Column(ForeignKey('userinfo.id'),
                             nullable=False, comment='承認申請ユーザーID')
    request_reason = Column(String(400), comment='依頼理由')
    request_day = Column(TIMESTAMP(precision=6), comment='依頼日時')
    approval_day = Column(TIMESTAMP(precision=6), comment='承認日時')
    approval_auth_type = Column(String(2), comment='承認時公開設定')
    datause_reasons = Column(ARRAY(Text()), comment='利用用途')
    datause_reasons_text = Column(String(100), comment='承認依頼情報')

    request_user = relationship('Userinfo')


class BasicAppFile(CommonModel):
    __tablename__ = 'basic_app_files'
    __table_args__ = {'comment': '申請基本情報添付ファイル'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('basic_app_files_id_seq'::regclass)"), comment='ID')
    basic_app_id = Column(ForeignKey('basic_apps.id'),
                          nullable=False, comment='申請基本情報ID')
    file_name = Column(String(255), comment='ファイル名')
    file_path = Column(String(255), comment='ファイルパス')
    file_category = Column(String(2), comment='ファイルカテゴリ')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, comment='作成日')

    basic_app = relationship('BasicApp')


class CmrcStatusReport(CommonModel):
    __tablename__ = 'cmrc_status_reports'
    __table_args__ = {'comment': '事業化状況報告'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('cmrc_status_reports_id_seq'::regclass)"), comment='ID')
    basic_app_id = Column(ForeignKey('basic_apps.id'),
                          nullable=False, comment='申請基本情報ID')
    cmrc_status_date = Column(Date, comment='事業化状況報告年月日')
    cmrc_result = Column(Boolean, comment='補助事業実施結果事業化有無')
    intellectual_prop_result_asg = Column(Boolean, comment='知的財産譲渡又は実施権設定有無')
    subsidy_result_asg = Column(Boolean, comment='その他補助事業実施結果他者供与有無')
    file_path = Column(String(255), comment='該当添付ファイル')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_app = relationship('BasicApp')


class ConsultSupportRecord(CommonModel):
    __tablename__ = 'consult_support_records'
    __table_args__ = {'comment': '支援/相談記録'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('consult_support_records_id_seq'::regclass)"), comment='ID')
    basic_app_id = Column(ForeignKey('basic_apps.id'),
                          nullable=False, comment='申請基本情報ID')
    support_start_date = Column(Date, comment='支援/相談開始年月日')
    support_end_date = Column(Date, comment='支援/相談終了年月日')
    support_type = Column(String(2), comment='支援/相談区分')
    support_title = Column(String(100), comment='支援/相談 件名')
    consult_content = Column(String(10000), comment='支援/相談内容要約')
    result_content = Column(String(10000), comment='支援実施内容要約')
    support_agency_code = Column(ForeignKey(
        'support_agencys.support_agency_code'), comment='支援機関コード')
    support_agency_name = Column(String(50), comment='支援機関名称')
    support_agency_name_kana = Column(String(50), comment='支援機関カナ名称')
    support_agency_branch_name = Column(String(50), comment='支援機関支店名称')
    support_agency_branch_name_kana = Column(String(50), comment='支援機関支店カナ名称')
    support_agency_type = Column(String(2), comment='支援機関属性区分')
    accredited_support_agency_type = Column(Boolean, comment='認定支援機関フラグ')
    regional_platform = Column(Boolean, comment='地域プラットフォーム区分')
    support_agency_feature = Column(String(10000), comment='支援機関特徴・分野')
    support_agency_staff_num = Column(BigInteger, comment='支援機関専門家数')
    ceterite_type = Column(Boolean, comment='サテライト・出張相談会協力区分')
    ceterite_achievement_frequency = Column(String(255), comment='サテライト等実績頻度')
    network_type = Column(Boolean, comment='ネットワーク構築対象機関区分')
    network_status_type = Column(String(2), comment='ネットワーク構築状況区分')
    network_constr_completion_date = Column(Date, comment='ネットワーク構築完了年月日')
    support_staff_last_name = Column(String(30), comment='支援機関担当者漢字氏名（姓）')
    support_staff_kana_last_name = Column(String(30), comment='支援機関担当者カナ氏名（姓）')
    support_staff_first_name = Column(String(30), comment='支援機関担当者漢字氏名（名）')
    support_staff_first_kana_name = Column(
        String(30), comment='支援機関担当者カナ氏名（名）')
    support_staff_department = Column(String(200), comment='支援機関担当者所属部署')
    support_staff_role = Column(String(255), comment='支援機関担当者役職')
    support_staff_qual = Column(String(10000), comment='支援機関担当者資格')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_app = relationship('BasicApp')
    support_agency = relationship('SupportAgency')


class DistributionChannel(CommonModel):
    __tablename__ = 'distribution_channels'
    __table_args__ = {'comment': '商流'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('distribution_channels_id_seq'::regclass)"), comment='ID')
    locaben_id = Column(ForeignKey(
        'locaben_non_financial_statuses.id'), nullable=False, comment='ローカルベンチマークID')
    transaction_amt = Column(Numeric, comment='取引金額')
    transaction_contents = Column(String(10000), comment='取引内容')
    biz_partner_type = Column(String(2), comment='取引先区分')
    chosen_reason = Column(String(10000), comment='選定/被選定理由')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    locaben = relationship('LocabenNonFinancialStatus')


class MstDistributionChannel(CommonModel):
    __tablename__ = 'mst_distribution_channels'
    __table_args__ = {'comment': '[マスタ]商流'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_distribution_channels_id_seq'::regclass)"), comment='ID')
    locaben_id = Column(ForeignKey(
        'mst_locaben_non_financial_statuses.id'), nullable=False, comment='ローカルベンチマークID')
    transaction_amt = Column(Numeric, comment='取引金額')
    transaction_contents = Column(String(10000), comment='取引内容')
    biz_partner_type = Column(String(2), comment='取引先区分')
    chosen_reason = Column(String(10000), comment='選定/被選定理由')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    locaben = relationship('MstLocabenNonFinancialStatus')


class MstValueCreateBiz(CommonModel):
    __tablename__ = 'mst_value_create_biz'
    __table_args__ = (
        UniqueConstraint('biz_flow_id', 'biz_order'),
        {'comment': '[マスタ]価値創出業務'}
    )

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_value_create_biz_id_seq'::regclass)"), comment='ID')
    biz_flow_id = Column(ForeignKey(
        'mst_value_create_biz_flow.id'), nullable=False, comment='業務フローID')
    biz_order = Column(Integer, nullable=False, comment='業務フロー並び順')
    biz_name = Column(String(50), comment='業務名')
    imple_content = Column(String(10000), comment='実施内容')
    differentiation_points = Column(String(10000), comment='差別化ポイント')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    biz_flow = relationship('MstValueCreateBizFlow')


class PerformanceReport(CommonModel):
    __tablename__ = 'performance_reports'
    __table_args__ = {'comment': '実績報告'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('performance_reports_id_seq'::regclass)"), comment='ID')
    basic_app_id = Column(ForeignKey('basic_apps.id'),
                          nullable=False, comment='申請基本情報ID')
    delivery_decision_date = Column(Date, comment='交付決定年月日')
    biz_start_record_date = Column(Date, comment='事業開始実績年月日')
    biz_end_record_date = Column(Date, comment='事業終了実績年月日')
    imple_assistance_project_outline = Column(
        String(10000), comment='実施補助事業概要記述')
    priority_action_items_desc = Column(String(10000), comment='重点実施事項記述')
    imple_subsidy_project_effect_desc = Column(
        String(10000), comment='実施補助事業効果記述')
    necessary_expenses_amt = Column(Numeric, comment='補助事業実績必要経費金額')
    subsidy_target_expenses_amt = Column(Numeric, comment='補助事業実績補助対象経費金額')
    subsidy_confirm_amt = Column(Numeric, comment='補助金交付確定金額')
    file_path = Column(String(255), comment='該当添付ファイル')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_app = relationship('BasicApp')


class StatusReport(CommonModel):
    __tablename__ = 'status_reports'
    __table_args__ = {'comment': '状況報告'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('status_reports_id_seq'::regclass)"), comment='ID')
    basic_app_id = Column(ForeignKey('basic_apps.id'),
                          nullable=False, comment='申請基本情報ID')
    status_report = Column(Date, comment='状況報告年月日')
    commercialization_result = Column(Boolean, comment='補助事業実施結果事業化有無')
    file_path = Column(String(255), comment='該当添付ファイル')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_app = relationship('BasicApp')


class SuccessionApp(CommonModel):
    __tablename__ = 'succession_app'
    __table_args__ = {'comment': '承継承認申請'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('succession_app_id_seq'::regclass)"), comment='ID')
    basic_app_id = Column(ForeignKey('basic_apps.id'),
                          nullable=False, comment='申請基本情報ID')
    biz_plan_name = Column(String(100), comment='事業計画名')
    succession_content = Column(String(10000), comment='承継内容')
    succession_reason = Column(String(10000), comment='承継理由')
    successor_last_name = Column(String(30), comment='承継者漢字氏名（姓）')
    successor_kana_last_name = Column(String(30), comment='承継者カナ氏名（姓）')
    successor_first_name = Column(String(30), comment='承継者漢字氏名（名）')
    successor_kana_first_name = Column(String(30), comment='承継者カナ氏名（名）')
    successor_add_pref_code = Column(String(2), comment='承継者住所都道府県コード')
    successor_add_city = Column(String(100), comment='承継者住所町名（郡・市区町村～町名）')
    successor_add_street = Column(String(100), comment='承継者住所丁目以下')
    successor_add_suburb = Column(String(100), comment='承継者住所建物名等')
    successor_add_code = Column(String(7), comment='承継者住所郵便番号')
    biz_enforcement_system = Column(String(10000), comment='承継による変更事業実施体制')
    succession_biz_change_content = Column(
        String(10000), comment='承継による事業変更内容')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    basic_app = relationship('BasicApp')


class UpdateDisclosureAuth(CommonModel):
    __tablename__ = 'update_disclosure_auth'
    __table_args__ = {'comment': '更新閲覧権限:更新時の公開権限設定'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('\"$$update_disclosure_auth_id_seq\"'::regclass)"), comment='ID')
    basic_app_id = Column(BigInteger, comment='申請基本情報ID')
    category_code = Column(String(2), comment='カテゴリコード')
    approval_corp_num = Column(String(13), comment='開示元法人番号')
    approval_user_id = Column(ForeignKey('userinfo.id'), comment='開示先ユーザーID')
    is_open = Column(Boolean, comment='公開設定:公開;非公開;指定なし')

    approval_user = relationship('Userinfo')


class ValueCreateBiz(CommonModel):
    __tablename__ = 'value_create_biz'
    __table_args__ = (
        UniqueConstraint('biz_flow_id', 'biz_order'),
        {'comment': '価値創出業務'}
    )

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('value_create_biz_id_seq'::regclass)"), comment='ID')
    biz_flow_id = Column(ForeignKey('value_create_biz_flow.id'),
                         nullable=False, comment='業務フローID')
    biz_order = Column(Integer, nullable=False, comment='業務フロー並び順')
    biz_name = Column(String(50), comment='業務名')
    imple_content = Column(String(10000), comment='実施内容')
    differentiation_points = Column(String(10000), comment='差別化ポイント')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    biz_flow = relationship('ValueCreateBizFlow')


class CmrcStatusReportFile(CommonModel):
    __tablename__ = 'cmrc_status_report_files'
    __table_args__ = {'comment': '事業化状況報告添付ファイル'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('cmrc_status_report_files_id_seq'::regclass)"), comment='ID')
    cmrc_status_report_id = Column(ForeignKey(
        'cmrc_status_reports.id'), nullable=False, comment='事業化状況報告ID')
    file_name = Column(String(255), comment='ファイル名')
    file_path = Column(String(255), comment='ファイルパス')
    file_category = Column(String(2), comment='ファイルカテゴリ')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    cmrc_status_report = relationship('CmrcStatusReport')


class ConsultSupportReportFile(CommonModel):
    __tablename__ = 'consult_support_report_files'
    __table_args__ = {'comment': '支援/相談記録添付ファイル'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('consult_support_report_files_id_seq'::regclass)"), comment='ID')
    consult_support_record_id = Column(ForeignKey(
        'consult_support_records.id'), nullable=False, comment='支援/相談ID')
    file_name = Column(String(255), comment='ファイル名')
    file_path = Column(String(255), comment='ファイルパス')
    file_category = Column(String(2), comment='ファイルカテゴリ')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    consult_support_record = relationship('ConsultSupportRecord')


class EndUser(CommonModel):
    __tablename__ = 'end_users'
    __table_args__ = {'comment': 'エンドユーザー'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('end_users_id_seq'::regclass)"), comment='ID')
    distribution_channel_id = Column(ForeignKey(
        'distribution_channels.id'), nullable=False, comment='商流ID')
    transaction_amt = Column(Numeric, comment='取引金額')
    transaction_contents = Column(String(10000), comment='取引内容')
    chosen_reason = Column(String(10000), comment='選定/被選定理由')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    distribution_channel = relationship('DistributionChannel')


class MstEndUser(CommonModel):
    __tablename__ = 'mst_end_users'
    __table_args__ = {'comment': '[マスタ]エンドユーザー'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('mst_end_users_id_seq'::regclass)"), comment='ID')
    distribution_channel_id = Column(ForeignKey(
        'mst_distribution_channels.id'), nullable=False, comment='商流ID')
    transaction_amt = Column(Numeric, comment='取引金額')
    transaction_contents = Column(String(10000), comment='取引内容')
    chosen_reason = Column(String(10000), comment='選定/被選定理由')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    distribution_channel = relationship('MstDistributionChannel')


class PerformanceReportFile(CommonModel):
    __tablename__ = 'performance_report_files'
    __table_args__ = {'comment': '実績報告添付ファイル'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('performance_report_files_id_seq'::regclass)"), comment='ID')
    performance_report_id = Column(ForeignKey(
        'performance_reports.id'), nullable=False, comment='実績報告ID')
    file_name = Column(String(255), comment='ファイル名')
    file_path = Column(String(255), comment='ファイルパス')
    file_category = Column(String(2), comment='ファイルカテゴリ')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    performance_report = relationship('PerformanceReport')


class StatusReportFile(CommonModel):
    __tablename__ = 'status_report_files'
    __table_args__ = {'comment': '状況報告添付ファイル'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('status_report_files_id_seq'::regclass)"), comment='ID')
    status_report_id = Column(ForeignKey(
        'status_reports.id'), nullable=False, comment='状況報告ID')
    file_name = Column(String(255), comment='ファイル名')
    file_path = Column(String(255), comment='ファイルパス')
    file_category = Column(String(2), comment='ファイルカテゴリ')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    status_report = relationship('StatusReport')


class SuccessionAppFile(CommonModel):
    __tablename__ = 'succession_app_files'
    __table_args__ = {'comment': '承継承認添付ファイル'}

    id = Column(BigInteger, primary_key=True, server_default=text(
        "nextval('succession_app_files_id_seq'::regclass)"), comment='ID')
    status_report_id = Column(ForeignKey(
        'succession_app.id'), nullable=False, comment='承継承認申請ID')
    file_name = Column(String(255), comment='ファイル名')
    file_path = Column(String(255), comment='ファイルパス')
    file_category = Column(String(2), comment='ファイルカテゴリ')
    updated_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='更新日')
    created_at = Column(DateTime, nullable=False, server_default=text(
        "CURRENT_TIMESTAMP"), comment='作成日')

    status_report = relationship('SuccessionApp')
