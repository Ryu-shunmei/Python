class XX():
    x = 1
