import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager

# USER = os.getenv('username')
# PASSWORD = os.getenv('password')
# HOST = os.getenv('host')
# PORT = os.getenv('port')
# ENGING = os.getenv('engine')

USER = 'postgres'
PASSWORD = 'postgres'
HOST = 'localhost'
PORT = 5432
ENGING = 'test1'

SQLALCHEMY_DATABASE_URL = f"postgresql://{USER}:{PASSWORD}@{HOST}:{PORT}/{ENGING}"

engine = create_engine(SQLALCHEMY_DATABASE_URL)
Session = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


@contextmanager
def session_scope():
    session = Session()
    try:
        yield session
        session.commit()
    except SQLAlchemyError as e:
        session.rollback()
        raise e
    finally:
        session.close()
