import io
import json
import boto3
import base64
from common.core.exceptions import JsonLoadException
from common.core.exceptions import WriteFileException
from common.core.exceptions import WriteJsonException


def load_json_from_s3(bucket: str, key: str, hyphen_transform: bool = True) -> dict:
    """load json to dict from s3
    return:
        dict_data:: dict
    """
    try:
        s3 = boto3.client('s3')

        json_str = s3.get_object(Bucket=bucket, Key=key).get(
            'Body').read().decode('utf-8')
        dict_data = json.loads(json_str)

        if hyphen_transform:
            temp = io.StringIO()
            for line in io.StringIO(json.dumps(json.loads(json_str))).readline():
                if line:
                    if '-' in line:
                        sep = ': '
                        _list = line.split(sep, 1)
                        _list[0] = _list[0].replace('-', '_')
                        new_line = sep.join(_list)
                        temp.write(new_line)
                    else:
                        temp.write(line)
            dict_data = json.loads(temp.getvalue())

        return dict_data
    except Exception:
        raise(JsonLoadException(bucket, key))


def write_file_s3(bucket: str, key: str, file_data: str) -> None:
    """write file to s3 with base64"""
    try:
        s3 = boto3.client('s3')
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=base64.b64decode(file_data)
        )
    except Exception:
        raise(WriteFileException(bucket, key, file_data))


def write_json_s3(bucket: str, key: str, json_data: str) -> None:
    """write json to s3"""
    try:
        s3 = boto3.client('s3')
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=json_data
        )
    except Exception:
        raise(WriteJsonException(bucket, key, json_data))
