class JsonLoadException(Exception):
    def __init__(self, s3_bucket: str, s3_key: str):
        self.message = f"[bucket: {s3_bucket}, key: {s3_key}]からファイルを読込失敗しました。"
        super().__init__(self.message)


class WriteFileException(Exception):
    def __init__(self, s3_bucket: str, s3_key: str, file_data: str):
        self.message = f"[bucket: {s3_bucket}, key: {s3_key}]にファイルを書込失敗しました。\n{file_data}"
        super().__init__(self.message)


class WriteJsonException(Exception):
    def __init__(self, s3_bucket: str, s3_key: str, json_data: str):
        self.message = f"[bucket: {s3_bucket}, key: {s3_key}]にJSONファイルを書込失敗しました。\n{json_data}"
        super().__init__(self.message)

