from common.database.database import session_scope
from common.database.models import ApprovalRequestInfo
from common.database.models import UpdateDisclosureAuth
from common.database.models import CategoryAssoc
from common.database.models import Userinfo
from common.database.models import DefaultDisclosureAuth


def file_access_permission_check(request_user_id, approval_corp_num, file_category_code):
    '''添付ファイルダウンロード用のアクセスコントロール共通機能:
    INPUT:
        request_user_id:: 承認申請ユーザーID
        approval_corp_num:: 承認者法人番号
        file_category_code:: 添付ファイルカテゴリコード
    OUTPUT:
        permission:: ダウンロードアクセス(True:許可, False:禁止)
    '''
    # ダウンロードアクセス初期化
    permission = False
    try:

        # 承認依頼情報取得
        with session_scope() as session:
            is_approval = session.query(ApprovalRequestInfo.approval_day).filter(
                ApprovalRequestInfo.request_user_id == request_user_id, ApprovalRequestInfo.approval_corp_num == approval_corp_num).first()

            if is_approval.approval_day:  # 承認依頼情報存在場合
                # アクセス取得
                auth_type = session.query(UpdateDisclosureAuth.auth_type).join(
                    CategoryAssoc, CategoryAssoc.category_code == UpdateDisclosureAuth.category_code).filter(
                        UpdateDisclosureAuth.approval_user_id == request_user_id, UpdateDisclosureAuth.approval_corp_num == approval_corp_num,
                        CategoryAssoc.file_category_code == file_category_code).first()
            else:  # 承認依頼情報存在ない場合
                # 支援機関グループコード取得
                support_agency_group_code = session.query(Userinfo.support_agency_group_code).filter(
                    Userinfo.corporate_number == approval_corp_num).first()
                # 支援機関グループコード存在ない場合、"00"になります。
                support_agency_group_code = support_agency_group_code if support_agency_group_code else "00"
                # アクセス取得
                auth_type = session.query(DefaultDisclosureAuth.auth_type).join(
                    CategoryAssoc, CategoryAssoc.category_code == DefaultDisclosureAuth.category_code).filter(
                        DefaultDisclosureAuth.approval_group_code == support_agency_group_code, CategoryAssoc.file_category_code == file_category_code).first()
    except Exception as e:
        print(e)
    finally:
        if auth_type:
            permission = True
        return permission
